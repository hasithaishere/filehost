var mqtt = require('mqtt');
var sys = require('systeminformation');
var machineId = require( "ee-machine-id" );
var Joi = require('joi');
var bunyan = require('bunyan');
var config = require('config');
var _ = require('underscore');

var appName = config.get('App.name');
var log = bunyan.createLogger({name: appName});

var validation = require('./helpers/validation');
var constents = require('./utilities/constents');
var jenkinsProxy = require('./proxies/jenkinsproxy');

// Parse 
var url = 'mqtt://m10.cloudmqtt.com';

var options = {
  port: 11895,
  clientId: 'mqttjs_' + Math.random().toString(16).substr(2, 8),
  username: 'ebshoqjf',
  password: '6VL4GW2Ngk0D',
  clean: false,
  reconnectPeriod: 1000 * 1,
  encoding: 'utf8'
};

var topicName = 'test';
var qos = { qos: 1 };

var topicName = 'hasi-chanel';

// Create a client connection
var client = mqtt.connect(url, options);

client.on('connect', function () {
    console.log('connected to the server');


    client.subscribe(topicName, qos);
});

client.on('message', function (topicName, message) {
    var convertedMsg = {};

    try{
        convertedMsg = JSON.parse(message)
    } catch (error) {
        log.info(error);
    }

    if(convertedMsg.hasOwnProperty('executable') && convertedMsg.executable) {
        console.log('got it');
        executeAction(convertedMsg);
    }
    console.log('====================>');
    console.log('received', JSON.stringify(convertedMsg));
    console.log('<====================');
});

client.on("error", function(error) {
    console.log("ERROR: ", error);
});

client.on('offline', function() {
    console.log("offline");
});

client.on('reconnect', function() {
    console.log("reconnect");
});

setTimeout(function(){
    var messageText = JSON.stringify({ machineid: '77d2a595-28e8-b25b-02ac-e5ba094b94cd', bindingid: '423435-gfe34235-fdsff3-fdsrf35', executable: true, data: {parameters: { jobName: 'Test', buildNumber: 31}, method: 'getBuildInfo'} });
    client.publish(topicName, messageText, qos, function(){
        console.log("sent ", 'Message Sent')
    });
}, 2000);

/*
sys.cpu(function(data) {
    console.log('CPU-Information:');
    console.log(data);
    machineId.get( function( id ){
        data.machineid = id;
	    client.publish(topicName, JSON.stringify(data), qos, function(){
            console.log("sent ", 'Message Sent')
        });
    });
    
});

sys.networkInterfaces(function(data) {
    console.log('Network-Information:');
    console.log(data);
});
*/

var executeAction = function(data) {
    // data - { machineid: 'eweqdsfasr234d234d2313', data: {parameters: {}, method: ''} }

    var inputResponse = _.isString(data) ? JSON.parse(data) : data;
    
    Joi.validate( inputResponse, validation.MAIN_RESPONSE, function (err, value) { 
        if (err) { log.info(err.details); return; }
        
        var bindingid = '';
    
        var successFunction = function(result) {
            var response = {};
            response.bindingid = bindingid;
            response.data = result;
            response.executable = false;

            client.publish(topicName, JSON.stringify(response), qos, function(){
                console.log("sent ", 'Result Published')
            });
        };
        
        var errorFunction = function(error) {
            log.info(error);
        };
        
        if (constents.MACHINE_ID === inputResponse.machineid) {
            bindingid = inputResponse.bindingid;
            switch (inputResponse.data.method) {
                case 'getAllJobs': 
                    Joi.validate( inputResponse.data.parameters, validation.EMPTY_OBJECT, function (err, value) { 
                        if (err) { log.info(err.details); return; }
                        jenkinsProxy.getAllJobs().then(successFunction).catch(errorFunction);
                    });
                    break;
                    
                case 'getJobInfo': 
                    Joi.validate( inputResponse.data.parameters, validation.WITH_JOB_NAME, function (err, value) { 
                        if (err) { log.info(err.details); return; }
                        jenkinsProxy.getJobInfo(inputResponse.data.parameters.jobName).then(successFunction).catch(errorFunction);
                    });
                    break;
                    
                case 'enableJob': 
                    Joi.validate( inputResponse.data.parameters, validation.WITH_JOB_NAME, function (err, value) { 
                        if (err) { log.info(err.details); return; }
                        jenkinsProxy.enableJob(inputResponse.data.parameters.jobName).then(successFunction).catch(errorFunction);
                    });
                    break;  
                    
                case 'disableJob': 
                    Joi.validate( inputResponse.data.parameters, validation.WITH_JOB_NAME, function (err, value) { 
                        if (err) { log.info(err.details); return; }
                        jenkinsProxy.disableJob(inputResponse.data.parameters.jobName).then(successFunction).catch(errorFunction);
                    });
                    break;
                
                case 'buildJob': 
                    Joi.validate( inputResponse.data.parameters, validation.WITH_JOB_NAME, function (err, value) { 
                        if (err) { log.info(err.details); return; }
                        jenkinsProxy.buildJob(inputResponse.data.parameters.jobName).then(successFunction).catch(errorFunction);
                    });
                    break;
                    
                case 'buildWithParams': 
                    Joi.validate( inputResponse.data.parameters, validation.WITH_BUILD_PARAMETERS, function (err, value) { 
                        if (err) { log.info(err.details); return; }
                        jenkinsProxy.buildWithParams(inputResponse.data.parameters.jobName, inputResponse.data.parameters.buildParamerters).then(successFunction).catch(errorFunction);
                    });
                    break;  
                    
                case 'stopBuild': 
                    Joi.validate( inputResponse.data.parameters, validation.WITH_JOB_NAME, function (err, value) { 
                        if (err) { log.info(err.details); return; }
                        jenkinsProxy.stopBuild(inputResponse.data.parameters.jobName).then(successFunction).catch(errorFunction);
                    });
                    break;
                    
                case 'getBuildInfo': 
                    Joi.validate( inputResponse.data.parameters, validation.WITH_BUILD_NUMBER, function (err, value) { 
                        if (err) { log.info(err.details); return; }
                        jenkinsProxy.getBuildInfo(inputResponse.data.parameters.jobName, inputResponse.data.parameters.buildNumber).then(successFunction).catch(errorFunction);
                    });
                    break;
                    
                case 'getLastBuildInfo': 
                    Joi.validate( inputResponse.data.parameters, validation.WITH_JOB_NAME, function (err, value) { 
                        if (err) { log.info(err.details); return; }
                        jenkinsProxy.getLastBuildInfo(inputResponse.data.parameters.jobName).then(successFunction).catch(errorFunction);
                    });
                    break;
                    
                case 'getLastBuildReport': 
                    Joi.validate( inputResponse.data.parameters, validation.WITH_JOB_NAME, function (err, value) { 
                        if (err) { log.info(err.details); return; }
                        jenkinsProxy.getLastBuildReport(inputResponse.data.parameters.jobName).then(successFunction).catch(errorFunction);
                    });
                    break;
                    
                case 'getConfigXml': 
                    Joi.validate( inputResponse.data.parameters, validation.WITH_JOB_NAME, function (err, value) { 
                        if (err) { log.info(err.details); return; }
                        jenkinsProxy.getConfigXml(inputResponse.data.parameters.jobName).then(successFunction).catch(errorFunction);
                    });
                    break
                    
                case 'getLastSuccessBuildInfo': 
                    Joi.validate( inputResponse.data.parameters, validation.WITH_JOB_NAME, function (err, value) { 
                        if (err) { log.info(err.details); return; }
                        jenkinsProxy.getLastSuccessBuildInfo(inputResponse.data.parameters.jobName).then(successFunction).catch(errorFunction);
                    });
                    break;
                    
                case 'getLastBuildResults':
                    Joi.validate( inputResponse.data.parameters, validation.WITH_JOB_NAME, function (err, value) { 
                        if (err) { log.info(err.details); return; }
                        jenkinsProxy.getLastBuildResults(inputResponse.data.parameters.jobName).then(successFunction).catch(errorFunction);
                    });
                    break;

                case 'getJobOutput':
                    Joi.validate( inputResponse.data.parameters, validation.WITH_BUILD_NUMBER, function (err, value) {
                        if (err) { log.info(err.details); return; }
                        jenkinsProxy.getJobOutput(inputResponse.data.parameters.jobName, inputResponse.data.parameters.buildNumber).then(successFunction).catch(errorFunction);
                    });
                    break;

                case 'getQueuedJobs':
                    Joi.validate( inputResponse.data.parameters, validation.EMPTY_OBJECT, function (err, value) {
                        if (err) { log.info(err.details); return; }
                        jenkinsProxy.getQueuedJobs().then(successFunction).catch(errorFunction);
                    });
                    break;

                case 'getAllJenkinsWorkers':
                    Joi.validate( inputResponse.data.parameters, validation.EMPTY_OBJECT, function (err, value) {
                        if (err) { log.info(err.details); return; }
                        jenkinsProxy.getAllJenkinsWorkers().then(successFunction).catch(errorFunction);
                    });
                    break;
            
                default: log.info(inputResponse.data.method + ' is not a implemented method. Please contact admin.');
                    break;
            }
        }

    });
    
}

//executeAction(JSON.stringify({ machineid: '77d2a595-28e8-b25b-02ac-e5ba094b94cd', bindingid: '423435-gfe34235-fdsff3-fdsrf35', executable: true, data: {parameters: { jobName: 'Test', buildNumber: 31}, method: 'getBuildInfo'} }));

//

var Joi = require('joi');
var bunyan = require('bunyan');
var config = require('config');

var appName = config.get('App.name');
var log = bunyan.createLogger({name: appName});
 
// var schema = Joi.object().keys({
//     username: Joi.string().alphanum().min(3).max(30).required(),
//     password: Joi.string().regex(/^[a-zA-Z0-9]{3,30}$/),
//     access_token: [Joi.string(), Joi.number()],
//     birthyear: Joi.number().integer().min(1900).max(2013),
//     email: Joi.string().email()
// }).with('username', 'birthyear').without('password', 'access_token');
 
// Joi.validate({ username: 'abc', birthyear: 1994, password: '3sss' }, schema, function (err, value) { 
//     console.log(err.details);
//     console.log(value);
    
// });  // err === null -> valid 


module.exports = {
    MAIN_RESPONSE: Joi.object().keys({
        machineid: Joi.string().required(),
        bindingid: Joi.string().required(),
        executable: Joi.boolean().required(),
        data: Joi.object().keys({ method: Joi.string(), parameters: Joi.object() })
    }),
    
    EMPTY_OBJECT: Joi.object().length(0),
    
    WITH_JOB_NAME: Joi.object().keys({
        jobName: Joi.string().required()
    }),
    
    WITH_BUILD_NUMBER: Joi.object().keys({
        jobName: Joi.string().required(),
        buildNumber: Joi.number().required()
    }),
    
    WITH_BUILD_PARAMETERS: Joi.object().keys({
        jobName: Joi.string().required(),
        buildParamerters: Joi.object().required()
    })
}
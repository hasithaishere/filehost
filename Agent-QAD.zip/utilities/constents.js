var machineId = require('machine-id');
    
    
exports.MACHINE_ID = machineId(true);
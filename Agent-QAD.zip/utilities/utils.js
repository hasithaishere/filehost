var _ = require('underscore');

module.exports = {
    generateUrl: function(urlTemplate, segments) {
        _.templateSettings = {
            interpolate: /\{(.+?)\}/g
        };

        var generatedUrl = _.template(urlTemplate);
        generatedUrl(segments);

        return generatedUrl;
    }
};
var bunyan = require('bunyan');
var promise = require('bluebird');
var config = require('config');
var jenkinsapi = require('jenkins-api');
var _ = require('underscore');
var url = require('url');

var appName = config.get('App.name');
var log = bunyan.createLogger({name: appName});

var jenkinsUrl = url.format({
    protocol: config.get('App.jenkins.protocol'),
    auth: config.get('App.jenkins.username') + ':' + config.get('App.jenkins.password'),
    host: config.get('App.jenkins.host')
})

console.log(jenkinsUrl)

var jenkins = jenkinsapi.init(jenkinsUrl);

module.exports = {
    
  getAllJobs: function() {
    return new promise(function(resolve, reject) {
        jenkins.all_jobs(function(err, data) {
            if (err) {
                log.info(err); 
                reject(err);
            }
            resolve(data);
        });
    });
  },
  
  getJobInfo: function(jobName) {
    return new promise(function(resolve, reject) {
        jenkins.job_info(jobName, function(err, data) {
            if (err) {
                log.info(err); 
                reject(err);
            }
            resolve(data);
        });
    });
  },
  
  enableJob: function(jobName) {
    return new promise(function(resolve, reject) {
        jenkins.enable_job(jobName, function(err, data) {
            if (err) {
                log.info(err); 
                reject(err);
            }
            resolve(data);
        });
    });
  },
  
  disableJob: function(jobName) {
    return new promise(function(resolve, reject) {
        jenkins.disable_job(jobName, function(err, data) {
            if (err) {
                log.info(err); 
                reject(err);
            }
            resolve(data);
        });
    });
  },
  
  buildJob: function(jobName) {
    return new promise(function(resolve, reject) {
        jenkins.build(jobName, function(err, data) {
            if (err) {
                log.info(err); 
                reject(err);
            }
            resolve(data);
        });
    });
  },
  
  buildWithParams: function(jobName, parameters) {
    return new promise(function(resolve, reject) {
        jenkins.build(jobName, parameters, function(err, data) {
            if (err) {
                log.info(err); 
                reject(err);
            }
            resolve(data);
        });
    });
  },
  
  stopBuild: function(jobName) {
    return new promise(function(resolve, reject) {
        jenkins.stop_build(jobName, function(err, data) {
            if (err) {
                log.info(err); 
                reject(err);
            }
            resolve(data);
        });
    });
  },
  
  getBuildInfo: function(jobName, buildNumber) {
    return new promise(function(resolve, reject) {
        jenkins.build_info(jobName, buildNumber, function(err, data) {
            if (err) {
                log.info(err); 
                reject(err);
            }
            resolve(data);
        });
    });
  },
  
  getLastBuildInfo: function(jobName) {
    return new promise(function(resolve, reject) {
        jenkins.last_build_info(jobName, function(err, data) {
            if (err) {
                log.info(err); 
                reject(err);
            }
            resolve(data);
        });
    });
  },
  
  getLastBuildReport: function(jobName) {
    return new promise(function(resolve, reject) {
        jenkins.last_build_report(jobName, function(err, data) {
            if (err) {
                log.info(err); 
                reject(err);
            }
            resolve(data);
        });
    });
  },
  
  getConfigXml: function(jobName) {
    return new promise(function(resolve, reject) {
        jenkins.get_config_xml(jobName, function(err, data) {
            if (err) {
                log.info(err); 
                reject(err);
            }
            resolve(data);
        });
    });
  },
  
  // TODO - Update, copy and delete job features need to add later
  
  getLastSuccessBuildInfo: function(jobName) {
    return new promise(function(resolve, reject) {
        jenkins.last_success(jobName, function(err, data) {
            if (err) {
                log.info(err); 
                reject(err);
            }
            resolve(data);
        });
    });
  },
  
  getLastBuildResults: function(jobName) {
    return new promise(function(resolve, reject) {
        jenkins.last_result(jobName, function(err, data) {
            if (err) {
                log.info(err); 
                reject(err);
            }
            resolve(data);
        });
    });
  },
  
  getJobOutput: function(jobName, buildName) {
    return new promise(function(resolve, reject) {
        jenkins.job_output(jobName, buildName, function(err, data) {
            if (err) {
                log.info(err); 
                reject(err);
            }
            resolve(data);
        });
    });
  },
  
  getQueuedJobs: function() {
    return new promise(function(resolve, reject) {
        jenkins.queue(function(err, data) {
            if (err) {
                log.info(err); 
                reject(err);
            }
            resolve(data);
        });
    });
  },
  
  getAllJenkinsWorkers: function() {
    return new promise(function(resolve, reject) {
        jenkins.computers(function(err, data) {
            if (err) {
                log.info(err); 
                reject(err);
            }
            resolve(data);
        });
    });
  },

  getAllJobsInView: function(viewInJenkins) { // This not still used in the mqtt wrapper
    return new promise(function(resolve, reject) {
        jenkins.all_jobs_in_view(viewInJenkins, function(err, data) {
            if (err) {
                log.info(err); 
                reject(err);
            }
            resolve(data);
        });
    });
  }
  
};
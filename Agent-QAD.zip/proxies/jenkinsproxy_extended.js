var bunyan = require('bunyan');
var promise = require('bluebird');
var config = require('config');
var jenkinsapi = require('jenkins-api');
var _ = require('underscore');
var url = require('url');

var appName = config.get('App.name');
var log = bunyan.createLogger({name: appName});

var jenkinsUrl = url.format({
    protocol: config.get('App.jenkins.protocol'),
    auth: config.get('App.jenkins.username') + ':' + config.get('App.jenkins.password'),
    host: config.get('App.jenkins.host')
})

var jenkins = require('jenkins')({ baseUrl: jenkinsUrl, crumbIssuer: false });

module.exports = {
    
  getJenkinsInfo: function() {
    return new promise(function(resolve, reject) {
        jenkins.info(function(err, data) {
            if (err) {
                log.info(err); 
                reject(err);
            }
            resolve(data);
        });
    });
  },
  
  buildJob: function(jobName) {
    return new promise(function(resolve, reject) {
        jenkins.job.build(jobName, function(err, data) {
            if (err) {
                log.info(err); 
                reject(err);
            }
            resolve(data);
        });
    });
  }
  
};
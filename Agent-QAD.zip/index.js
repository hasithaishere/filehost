var utils = require('./utils.js');
var jenkinsProxy = require('./proxies/jenkinsproxy');

/*jenkinsProxy.buildJob('Test').then(function(result) { 
    //console.log('++++++++++++++++++++++++');
    console.log(result);
}).catch(function(error) {
  console.log(' [Error] : ', error);
});*/



/*
jenkinsProxy.buildJob('Test').then(function(result) { 
    console.log('====================');
    console.log(result);
}).catch(function(error) {
  console.log(' [Error] : ', error);
});
*/
/*
var jenkinsapi = require('jenkins-api');
var jenkins = jenkinsapi.init('http://admin:hp104503@jenkins-hasitha.rhcloud.com');

jenkins.build('Test', function(err, data) {
  if (err){ return console.log(err); }
  console.log(data)
});*/

/*
var mqtt = require('mqtt');
var conn = mqtt.createConnection(
    11895, 
    'm10.cloudmqtt.com', 
    function(err, client) {
  if (err) throw err;

  client.connect({
    protocolId: 'MQIsdp',
    protocolVersion: 3,
    clientId: 'YoMan-1',
    keepalive: 30000,
    username: 'ebshoqjf',
    password: '6VL4GW2Ngk0D'
  });

  client.on('connact', function(packet) {
    if (packet.returnCode !== 0) {
      throw 'Connect error'
    }
    client.publish({
      topic: 'example',
      payload: new Buffer('example', 'utf8')
    });
  });
});
*/

var mqtt = require('mqtt');
    
// Parse 
var url = 'mqtt://m10.cloudmqtt.com';

var options = {
  port: 11895,
  clientId: 'mqttjs_' + Math.random().toString(16).substr(2, 8),
  username: 'ebshoqjf',
  password: '6VL4GW2Ngk0D'
};

var topicName = 'hasi-chanel';

// Create a client connection
var client = mqtt.connect(url, options);

client.on('connect', function() { // When connected

  // subscribe to a topic
  client.subscribe(topicName, function() {
    // when a message arrives, do something with it
    client.on('message', function(topic, message, packet) {
      console.log("Received '" + message + "' on '" + topic + "'");
    });
  });

  // publish a message to a topic
  client.publish(topicName, 'my message', function() {
    console.log("Message is published");
    client.end(); // Close the connection when published
  });
});